from flask import Flask, request, jsonify
from flask_cors import CORS
import os

app = Flask(__name__)
CORS(app)

bot_status = {"status": "offline", "mode": "manual"}

@app.route('/')
def index():
    return jsonify({"message": "Killer Trade API is running."})

@app.route('/start', methods=['POST'])
def start_trading():
    bot_status["status"] = "running"
    bot_status["mode"] = request.json.get("mode", "manual")
    return jsonify({"message": "Trading started", "status": bot_status})

@app.route('/stop', methods=['POST'])
def stop_trading():
    bot_status["status"] = "stopped"
    return jsonify({"message": "Trading stopped", "status": bot_status})

@app.route('/status', methods=['GET'])
def get_status():
    return jsonify(bot_status)

if __name__ == '__main__':
    port = int(os.environ.get("PORT", 10000))
    app.run(host='0.0.0.0', port=port)
